import java.io.*;
import java.util.ArrayList;

public class VeiculoService {
    private ArrayList<Veiculo> veiculos = new ArrayList<>();
    private final String arquivo = "veiculos.txt";

    public VeiculoService() {
        carregar();
    }

    public void cadastrar(Veiculo v) throws Exception {
        if (buscarPorPlaca(v.getPlaca()) != null) {
            throw new Exception("Placa já cadastrada.");
        }
        veiculos.add(v);
        salvar();
        System.out.println("Veículo cadastrado com sucesso.");
    }

    public void listar() {
        if (veiculos.isEmpty()) {
            System.out.println("Nenhum veículo cadastrado.");
        } else {
            for (Veiculo v : veiculos) {
                v.exibir();
            }
        }
    }

    public void atualizar(String placa, String novaMarca, String novoModelo) throws Exception {
        Veiculo v = buscarPorPlaca(placa);
        if (v == null) throw new Exception("Veículo não encontrado.");
        v.setMarca(novaMarca);
        v.setModelo(novoModelo);
        salvar();
        System.out.println("Veículo atualizado com sucesso.");
    }

    public void remover(String placa) throws Exception {
        Veiculo v = buscarPorPlaca(placa);
        if (v == null) throw new Exception("Veículo não encontrado.");
        veiculos.remove(v);
        salvar();
        System.out.println("Veículo removido com sucesso.");
    }

    public void manutencao(String placa) throws Exception {
        Veiculo v = buscarPorPlaca(placa);
        if (v == null) throw new Exception("Veículo não encontrado.");
        v.manutencao();
    }

    private Veiculo buscarPorPlaca(String placa) {
        for (Veiculo v : veiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                return v;
            }
        }
        return null;
    }

    private void salvar() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo))) {
            for (Veiculo v : veiculos) {
                bw.write(v.getTipo() + ";" + v.getPlaca() + ";" + v.getMarca() + ";" + v.getModelo());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        }
    }

    private void carregar() {
        File file = new File(arquivo);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] p = linha.split(";");
                if (p.length == 4) {
                    veiculos.add(new Veiculo(p[0], p[1], p[2], p[3]));
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar: " + e.getMessage());
        }
    }
}