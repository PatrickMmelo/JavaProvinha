public class Veiculo {
    private String tipo;
    private String placa;
    private String marca;
    private String modelo;

    public Veiculo(String tipo, String placa, String marca, String modelo) {
        this.tipo = tipo;
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
    }

    public void exibir() {
        System.out.println(tipo + " - Placa: " + placa + ", Marca: " + marca + ", Modelo: " + modelo);
    }

    public void manutencao() {
        System.out.println("Realizando manutenção no " + tipo.toLowerCase() + " de placa " + placa);
    }

    public String getTipo() {
        return tipo;
    }

    public String getPlaca() {
        return placa;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}