import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        VeiculoService service = new VeiculoService();
        int opcao;

        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1 - Cadastrar veículo");
            System.out.println("2 - Listar veículos");
            System.out.println("3 - Atualizar veículo");
            System.out.println("4 - Remover veículo");
            System.out.println("5 - Realizar manutenção");
            System.out.println("6 - Sair");
            System.out.print("Opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());

                switch (opcao) {
                    case 1 -> {
                        System.out.print("Tipo (Carro/Moto): ");
                        String tipo = scanner.nextLine();
                        System.out.print("Placa: ");
                        String placa = scanner.nextLine();
                        System.out.print("Marca: ");
                        String marca = scanner.nextLine();
                        System.out.print("Modelo: ");
                        String modelo = scanner.nextLine();
                        service.cadastrar(new Veiculo(tipo, placa, marca, modelo));
                    }
                    case 2 -> service.listar();
                    case 3 -> {
                        System.out.print("Placa: ");
                        String placa = scanner.nextLine();
                        System.out.print("Nova marca: ");
                        String marca = scanner.nextLine();
                        System.out.print("Novo modelo: ");
                        String modelo = scanner.nextLine();
                        service.atualizar(placa, marca, modelo);
                    }
                    case 4 -> {
                        System.out.print("Placa: ");
                        String placa = scanner.nextLine();
                        service.remover(placa);
                    }
                    case 5 -> {
                        System.out.print("Placa: ");
                        String placa = scanner.nextLine();
                        service.manutencao(placa);
                    }
                    case 6 -> System.out.println("Saindo...");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
                opcao = 0;
            }
        } while (opcao != 6);
    }
}